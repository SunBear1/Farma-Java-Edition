/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package po_2;
/**
 *
 * @author lukin
 */
public class PO_2{

    /**
     * @param args the command line arguments
     */
     
    //static GraphicsConfiguration gc;
    public static void main(String[] args) {
        swiat ziemia = new swiat(20,20);
        ziemia.Start();
        }
    }
